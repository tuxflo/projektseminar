#ifndef Constants_h
#define Constants_h

#define BUFFER_SIZE 256
#define ELEMENT_COUNT 100000

#endif
